#include <iostream>
#include <string> 

using namespace std;


void sentenceSwap(string sentence1, string sentence2)
{	
	cout << "Sentence 1 is currently: ";
	cout << sentence1 << endl;
	cout << endl;

	cout << "Sentence 2 is currently: ";
	cout << sentence2 << endl;
	cout << endl;

	string tempSentence = sentence1;
	sentence1 = sentence2;
	sentence2 = tempSentence;

	
	cout << "Sentence 1 is now: ";
	cout << sentence1 << endl;
	cout << endl;

	cout << "Sentence 2 is now: ";
	cout << sentence2 << endl;
	cout << endl;
	
}

int main()
{
	string sentence1;
	string sentence2;
	bool check;

	check = false;
	while(!check)
	{
		cout << "Enter a sentence." << endl;

	
		getline(cin, sentence1);

		if(!cin)
		{
			cin.clear();
			cin.ignore(1000000,'\n');
			cout << "Enter a valid value." << endl;
			cout << endl;
		}
		else
			check = true;
	}

	check = false;
	
	while(!check)
	{
		cout << "Enter a sentence." << endl;
		getline(cin, sentence2);

		if(!cin)
		{
			cin.clear();
			cin.ignore(1000000,'\n');
			cout << "Enter a valid value." << endl;
			cout << endl;
		}
		else
			check = true;
	}
	
	sentenceSwap(sentence1, sentence2);
	
	return 0;
}




























